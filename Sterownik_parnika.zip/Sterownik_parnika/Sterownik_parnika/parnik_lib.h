#ifndef DISPLAY_H
#define DISPLAY_H
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <avr/io.h>



typedef struct {
    uint16_t H;
    uint16_t M;
}TIME;
extern TIME ram_zw;
extern TIME eem_zw EEMEM;
extern const TIME pgm_zw PROGMEM;


#define FALSE 0
#define TRUE 1
#define h 0
#define m 0
#define gg (1<<PB4)
#define mm (1<<PB5)
#define dig1 (1<<PB1)
#define dig2 (1<<PB2)
#define dig3 (1<<PB3)
#define time (1<<PC4)
#define temp (1<<PC3)
#define grzanie (1<<PC2)
#define zwloka (1<<PC1);
#define grzalka (1<<PD7)
#define ust (1<<PC0)
#define clear_C PORTC = 0b1111
#define t_ADC PC5



void copy_ram_to_eem(void);
void copy_eem_to_ram(void);
void print(unsigned int liczba, int czas);
void print_ERR(void);
void init();
TIME ustawienia(TIME ram_zw);
void odliczanie(TIME ram_zw,uint8_t *wyjscie);
unsigned int get_temp(void);
void parowanie(void);
void all_off(void);

void copy_pgm_to_ram(void);
#endif

