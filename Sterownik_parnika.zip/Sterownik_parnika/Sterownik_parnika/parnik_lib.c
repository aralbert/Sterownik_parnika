#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include "parnik_lib.h"

/****************************************************/
void print(unsigned int liczba, int czas){
        const int tablica[] = {64 , 121 , 36 , 48 , 25 , 18 , 2 , 120 , 0 , 16 , 127};
                              //0    1     2    3    4    5   6    7    8    9   10
        unsigned int wsw1 = 0, wsw10 = 0, wsw100 = 0;
        if (czas == 1){
            wsw1 = liczba % 10;
            liczba = liczba / 10;
            wsw10 = liczba %10;
            liczba = liczba / 10;
            wsw100 = liczba %10;

            PORTB &= ~dig1; //dig1
            PORTB |= dig2; //dig2
            PORTB |= dig3; //dig3
            PORTD = tablica[wsw100];
            _delay_us(100);
            PORTD = tablica[10];

        } else if (czas == 0) {
         wsw1 = liczba % 10;
            liczba = liczba / 10;
            wsw10 = liczba %10;
        }

            PORTB |= dig1; //dig1
            PORTB |= dig2; //dig2
            PORTB &= ~dig3; //dig3
            PORTD = tablica[wsw1];
            _delay_us(100);
            PORTD = tablica[10];

            PORTB |= dig1; //dig1
            PORTB &= ~dig2; //dig2
            PORTB |= dig3; //dig3
            PORTD = tablica[wsw10];
            _delay_us(100);
            PORTD = tablica[10];

    }

/****************************************************/
    void init(void){
        DDRB = 0b00001111;
        DDRD = 0b11111111;
        DDRC = 0b11110000;
        clear_C;
      //  PORTC = 0xFF;
        PORTC &=~ time;
        PORTB |= gg|mm;



        //------Przetwornik ADC
        //Uruchomienie ADC, wewnêtrzne napiecie odniesienia, tryb pojedynczej konwersji, preskaler 128, wejœcie PIN5, wynik do prawej
        ADCSRA = 	 (1<<ADEN)//Bit 7 – ADEN: ADC Enable (uruchomienie przetwornika)
        			|(1<<ADPS0)
        			|(1<<ADPS1)
        			|(1<<ADPS2);//ADPS2:0: ADC Prescaler Select Bits (ustawienie preskalera) preskaler= 128

        ADMUX  =	 (1<<REFS1) | (1<<REFS0)//Bit 7:6 – REFS1:0: Reference Selection Bits
        									//Internal 2.56V Voltage Reference with external capacitor at AREF pin
        			 |(1<<MUX2) | (1<<MUX0);//Input Channel Selections (ADC5 - Pin 5 )

        DDRC &=~ (1<<t_ADC);
    }
/****************************************************/

/****************************************************/
void print_ERR(void){
clear_C;
PORTC &= ~grzanie;
PORTD &= ~grzalka;
    while(1){

            PORTB |= dig1; //dig1
            PORTB |= dig2; //dig2
            PORTB &= ~dig3; //dig3
            PORTD = 47;

            _delay_us(100);
            PORTD = 127;

           PORTB |= dig1; //dig1
            PORTB &= ~dig2; //dig2
            PORTB |= dig3; //dig3
            PORTD = 47;

            _delay_us(100);
            PORTD = 127;

            PORTB &= ~dig1; //dig1
            PORTB |= dig2; //dig2
            PORTB |= dig3; //dig3
            PORTD = 6;

            _delay_us(100);
            PORTD = 127;
    }
}
/****************************************************/
TIME ustawienia(TIME ram_zw){
        uint16_t godz_lock=0, min_lock=0, t=0;
        clear_C;
        PORTC |= ust;
        PORTC |= time;
        do{
            t++;
             if (!godz_lock &&!(PINB & gg)){
                godz_lock=50000;
                ram_zw.H++;
                t=0;
                if (ram_zw.H > 9 ) ram_zw.H = 0;
            }else if (godz_lock && (PINB & gg)) godz_lock=0;

            if (!min_lock &&!(PINB & mm)){
                min_lock=50000;
                ram_zw.M+=10;
                t=0;
                if (ram_zw.M > 50) ram_zw.M = 0;
            }else if (min_lock && (PINB & mm)) min_lock=0;
            print(ram_zw.H*100+ram_zw.M,1);
        }while(t<=1500);
        TIME zw={ram_zw.H, ram_zw.M};

        return zw;
}
/****************************************************/

void odliczanie(TIME ram_zw,uint8_t *wyjscie)
{
            uint16_t lock=0, k = 0, t = 0;
            TCCR1B |= ((1 << CS10) | (1 << CS11)); // Uruchamiamy licznik z czêstotliwoœci¹ FCPU/1024
            clear_C;
            PORTC |= zwloka;
            PORTC |= time;
            uint8_t s=60;
            copy_ram_to_eem();

        while(ram_zw.H*60+ram_zw.M!=0) {

                if (!lock &&!(PINB & gg)){
                lock=50000;
                k ++;
                if (k==2){
                    *wyjscie = TRUE;
                    break;
                }
            }else if (lock && (PINB & gg)) lock=0;
                if (k == 1) t++;
                if (t == 2000) k=0;


                if (TCNT1 >= 15360)
                    {
                     --s;
                    if (s <= 0) {
                            --ram_zw.M;
                            s=60;

                   if (ram_zw.M == -1 ){
                        --ram_zw.H;
                        ram_zw.M = 59;
                        }
                    }
                        TCNT1 = 0;
                    }

            print(ram_zw.H*100+ram_zw.M,1);

        }
}

/***************************************************/
unsigned int get_temp(void){
	unsigned int odczyt;
	if (TCNT1 >= 15360){
		ADCSRA |= (1<<ADSC);//Bit 6 – ADSC: ADC Start Conversion (uruchomienie pojedynczej konwersji
		while(ADCSRA & (1<<ADSC));//czeka na zakoñczenie konwersji
		odczyt = ( (int)ADC * 0.48828125);
	}
	return odczyt;
}

/***************************************************/

void copy_eem_to_ram(void){
    eeprom_read_block(&ram_zw,&eem_zw,sizeof(ram_zw));
}

/***************************************************/
void copy_ram_to_eem(void){
    eeprom_write_block(&ram_zw,&eem_zw,sizeof(ram_zw));
}

/***************************************************/
void parowanie(void){

	uint8_t odczyt;
	do{
		PORTC |= grzanie;
		PORTD |= grzalka;
		TCCR1B |= ((1 << CS10) | (1 << CS11)); // Uruchamiamy licznik z czêstotliwoœci¹ FCPU/1024
			if (TCNT1 >= 15360){
				odczyt = get_temp();
				TCNT1 = 0;
				}
			print(odczyt,0);

		//	if (odczyt > 98) print_ERR();
	}while(odczyt <= 96);

	PORTC &= ~grzanie;
	PORTD &= ~grzalka;
}

/***************************************************/
void all_off(void){
	PORTC = 0x00;
	PORTB = 0x00;
	PORTD = 0x00;
}
/***************************************************/

void copy_pgm_to_ram(void){
    memcpy_P(&ram_zw,&pgm_zw,sizeof(ram_zw));
}
