
#define F_CPU 12000000UL
#include <util/delay.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/pgmspace.h>
#include <avr/io.h>
#include "parnik_lib.h"

TIME ram_zw;
TIME eem_zw EEMEM;

const TIME pgm_zw PROGMEM = {
        h,
        m};

int main(void)
{
	uint16_t lock=0, k = 0, t = 0;
	unsigned int temperatura;
	uint8_t wyjscie = FALSE;


//Przywracanie ustawień fabrycznych
	 if (!lock &&!(PINB & gg)){
		 lock=5000;
		 copy_pgm_to_ram();
		 copy_ram_to_eem();

	 }else if (lock && (PINB & gg)) lock=0;


do{
	_delay_ms(300);
    init();
    //wczytanie czasu z pamięci eeprom
    copy_eem_to_ram();
    do{
        wyjscie = FALSE;
        ram_zw=ustawienia(ram_zw);
        odliczanie(ram_zw,&wyjscie);
    }while(wyjscie == TRUE);


    //Uruchomienie grzałki i odczytu temperatury
    parowanie();

   //Wyswietlanie temperatury
    temperatura = get_temp();
    if (temperatura >= 30){
    	TCCR1B |= ((1 << CS10) | (1 << CS11)); // Uruchamiamy licznik z czêstotliwoœci¹ FCPU/1024
    	if (TCNT1 >= 15360){
    		temperatura = get_temp();
    		TCNT1 = 0;
    		}
    	print(temperatura,0);
    	if (temperatura >= 98) print_ERR();
    	}
    	else
    	{
    		wyjscie = FALSE;
    		all_off();
    	}

    	if (temperatura < 50){
    		 if (!lock &&!(PINB & gg)){
    			 lock=50000;
    			 k ++;
    		     if (k==2){
    		          wyjscie = TRUE;
    		          break;
    		     }
    		 }
    	}else if (lock && (PINB & gg)) lock=0;
        if (k == 1) t++;
        if (t == 2000) k=0;

}while(TRUE);

    return 0;

}

